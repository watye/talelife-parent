package com.talelife.project.service;
import com.talelife.project.model.Book;
import java.util.List;
/**
 * 书籍业务接口
 * date: 2017-02-09 14:38:55
 * 
 * @author Liuweiyao
 * @version 1.0
 */
public interface BookService{
	List<Book> findAll();
	
	List<Book> findList(Book book);
	
	int add(Book book);
	
	int delete(Long id);
	
	int update(Book book);
	
	Book findByPK(Long id);
}