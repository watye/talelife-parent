package com.talelife.project.test;
import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.talelife.project.service.BookService;

/**
 * 书籍测试用例
 * date: 2017-02-09 14:38:55
 * 
 * @author Liuweiyao
 * @version 1.0
 */
@RunWith(SpringRunner.class)
@ContextConfiguration("/spring-context.xml")
public class BookTest {
	 @Autowired
	 private BookService bookService;
	 
	 @Test
	 public void testFindAll(){
		 bookService.findAll();
	 }
}
