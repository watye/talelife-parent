package com.talelife.project.service.impl;
import org.springframework.stereotype.Service;
import com.talelife.project.service.BookService;
import com.talelife.project.mapper.BookMapper;
import com.talelife.project.model.Book;
import javax.annotation.Resource;
import java.util.List;
/**
 * 书籍业务实现类
 * date: 2017-02-09 14:38:55
 * 
 * @author Liuweiyao
 * @version 1.0
 */
@Service
public class BookServiceImpl implements BookService{
	
	@Resource
	private BookMapper bookMapper;
	
	public List<Book> findAll(){
		return bookMapper.findAll();
	}
	
	public List<Book> findList(Book book){
		return bookMapper.findList(book);
	}
	
	public int add(Book book){
		return bookMapper.add(book);
	}
	
	public int delete(Long id){
		return bookMapper.delete(id);
	}
	
	public int update(Book book){
		return bookMapper.update(book);
	}
	
	public Book findByPK(Long id){
		return bookMapper.findByPK(id);
	}
	
	
	
	
	
}