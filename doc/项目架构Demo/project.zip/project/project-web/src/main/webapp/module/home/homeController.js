app.controller('homeController', function ($scope) { 
	$scope.nums = [1,2,3,4];
})