app.controller('bookController', function ($scope) { 
	$scope.list = [{"name":"b1","price":1},{"name":"b2","price":2}];
})