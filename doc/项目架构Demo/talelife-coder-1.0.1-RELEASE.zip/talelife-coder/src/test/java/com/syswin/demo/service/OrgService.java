package com.syswin.demo.service;
import com.syswin.demo.model.Org;
import java.util.List;
/**
 * 组织单元业务接口
 * date: 2017-01-20 16:14:49
 * 
 * @author Liuweiyao
 * @version 1.0
 */
public interface OrgService{
	List<Org> findAll();
	
	List<Org> findList(Org org);
	
	int add(Org org);
	
	int delete(Long orgUnitId);
	
	int update(Org org);
	
	Org findByPK(Long orgUnitId);
}