package com.syswin.demo.service;
import com.syswin.demo.model.ManageProject;
import java.util.List;
/**
 * 管理项目业务接口
 * date: 2017-01-20 16:14:49
 * 
 * @author Liuweiyao
 * @version 1.0
 */
public interface ManageProjectService{
	List<ManageProject> findAll();
	
	List<ManageProject> findList(ManageProject manageProject);
	
	int add(ManageProject manageProject);
	
	int delete(Long manageProjectId);
	
	int update(ManageProject manageProject);
	
	ManageProject findByPK(Long manageProjectId);
}