package com.syswin.demo.test;
import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.syswin.demo.service.ManageProjectService;

/**
 * 管理项目测试用例
 * date: 2017-01-20 16:14:49
 * 
 * @author Liuweiyao
 * @version 1.0
 */
@RunWith(SpringRunner.class)
@ContextConfiguration("/spring-context.xml")
public class ManageProjectTest {
	 @Autowired
	 private ManageProjectService manageProjectService;
	 
	 @Test
	 public void testFindAll(){
		 manageProjectService.findAll();
	 }
}
