package com.syswin.demo.test;
import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.syswin.demo.service.OrgService;

/**
 * 组织单元测试用例
 * date: 2017-01-20 16:14:49
 * 
 * @author Liuweiyao
 * @version 1.0
 */
@RunWith(SpringRunner.class)
@ContextConfiguration("/spring-context.xml")
public class OrgTest {
	 @Autowired
	 private OrgService orgService;
	 
	 @Test
	 public void testFindAll(){
		 orgService.findAll();
	 }
}
