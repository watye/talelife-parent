package com.syswin.demo.mapper;
import com.syswin.demo.model.ManageProject;
import java.util.List;
/**
 * 管理项目数据操作接口
 * date: 2017-01-20 16:14:49
 * 
 * @author Liuweiyao
 * @version 1.0
 */
public interface ManageProjectMapper{
	List<ManageProject> findAll();
	
	List<ManageProject> findList(ManageProject manageProject);
	
	int add(ManageProject manageProject);
	
	int update(ManageProject manageProject);
	
	ManageProject findByPK(Long manageProjectId);
	
	int delete(Long manageProjectId);
}