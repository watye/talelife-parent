package com.syswin.demo.mapper;
import com.syswin.demo.model.Org;
import java.util.List;
/**
 * 组织单元数据操作接口
 * date: 2017-01-20 16:14:49
 * 
 * @author Liuweiyao
 * @version 1.0
 */
public interface OrgMapper{
	List<Org> findAll();
	
	List<Org> findList(Org org);
	
	int add(Org org);
	
	int update(Org org);
	
	Org findByPK(Long orgUnitId);
	
	int delete(Long orgUnitId);
}