package com.syswin.demo.service.impl;
import org.springframework.stereotype.Service;
import com.syswin.demo.service.ManageProjectService;
import com.syswin.demo.mapper.ManageProjectMapper;
import com.syswin.demo.model.ManageProject;
import javax.annotation.Resource;
import java.util.List;
/**
 * 管理项目业务实现类
 * date: 2017-01-20 16:14:49
 * 
 * @author Liuweiyao
 * @version 1.0
 */
@Service
public class ManageProjectServiceImpl implements ManageProjectService{
	
	@Resource
	private ManageProjectMapper manageProjectMapper;
	
	public List<ManageProject> findAll(){
		return manageProjectMapper.findAll();
	}
	
	public List<ManageProject> findList(ManageProject manageProject){
		return manageProjectMapper.findList(manageProject);
	}
	
	public int add(ManageProject manageProject){
		return manageProjectMapper.add(manageProject);
	}
	
	public int delete(Long manageProjectId){
		return manageProjectMapper.delete(manageProjectId);
	}
	
	public int update(ManageProject manageProject){
		return manageProjectMapper.update(manageProject);
	}
	
	public ManageProject findByPK(Long manageProjectId){
		return manageProjectMapper.findByPK(manageProjectId);
	}
	
	
	
	
	
}