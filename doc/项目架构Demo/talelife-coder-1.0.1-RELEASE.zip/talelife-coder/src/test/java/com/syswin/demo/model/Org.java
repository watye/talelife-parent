package com.syswin.demo.model;
import java.util.Date;
/**
 * 组织单元实体类
 * date: 2017-01-20 16:14:49
 * 
 * @author Liuweiyao
 * @version 1.0
 */
public class Org{
	//组织单元id
	private Long orgUnitId;
	
	//父节点
	private Long parentOrgUnitId;
	
	//组织名称
	private String orgUnitName;
	
	//组织单元全称
	private String orgUnitFullname;
	
	//组织单元级别（1集团2区域公司3公司4管理项目5部门6工作组）
	private Integer orgUnitLevel;
	
	//排序
	private Integer orderNo;
	
	//ets_id
	private String etsId;
	
	//ets_parentid
	private String etsParentid;
	
	//节点路径
	private String orgNodePath;
	
	//创建者id
	private Long createby;
	
	//创建者名称
	private String createbyName;
	
	//创建时间
	private Date createDate;
	
	//修改者id
	private Long updateby;
	
	//修改者名称
	private String updatebyName;
	
	//修改时间
	private Date updateDate;
	

	public Long getOrgUnitId(){
		return orgUnitId;
	}
	
	public Long setOrgUnitId(Long orgUnitId){
 	    return this.orgUnitId=orgUnitId;
    }
	public Long getParentOrgUnitId(){
		return parentOrgUnitId;
	}
	
	public Long setParentOrgUnitId(Long parentOrgUnitId){
 	    return this.parentOrgUnitId=parentOrgUnitId;
    }
	public String getOrgUnitName(){
		return orgUnitName;
	}
	
	public String setOrgUnitName(String orgUnitName){
 	    return this.orgUnitName=orgUnitName;
    }
	public String getOrgUnitFullname(){
		return orgUnitFullname;
	}
	
	public String setOrgUnitFullname(String orgUnitFullname){
 	    return this.orgUnitFullname=orgUnitFullname;
    }
	public Integer getOrgUnitLevel(){
		return orgUnitLevel;
	}
	
	public Integer setOrgUnitLevel(Integer orgUnitLevel){
 	    return this.orgUnitLevel=orgUnitLevel;
    }
	public Integer getOrderNo(){
		return orderNo;
	}
	
	public Integer setOrderNo(Integer orderNo){
 	    return this.orderNo=orderNo;
    }
	public String getEtsId(){
		return etsId;
	}
	
	public String setEtsId(String etsId){
 	    return this.etsId=etsId;
    }
	public String getEtsParentid(){
		return etsParentid;
	}
	
	public String setEtsParentid(String etsParentid){
 	    return this.etsParentid=etsParentid;
    }
	public String getOrgNodePath(){
		return orgNodePath;
	}
	
	public String setOrgNodePath(String orgNodePath){
 	    return this.orgNodePath=orgNodePath;
    }
	public Long getCreateby(){
		return createby;
	}
	
	public Long setCreateby(Long createby){
 	    return this.createby=createby;
    }
	public String getCreatebyName(){
		return createbyName;
	}
	
	public String setCreatebyName(String createbyName){
 	    return this.createbyName=createbyName;
    }
	public Date getCreateDate(){
		return createDate;
	}
	
	public Date setCreateDate(Date createDate){
 	    return this.createDate=createDate;
    }
	public Long getUpdateby(){
		return updateby;
	}
	
	public Long setUpdateby(Long updateby){
 	    return this.updateby=updateby;
    }
	public String getUpdatebyName(){
		return updatebyName;
	}
	
	public String setUpdatebyName(String updatebyName){
 	    return this.updatebyName=updatebyName;
    }
	public Date getUpdateDate(){
		return updateDate;
	}
	
	public Date setUpdateDate(Date updateDate){
 	    return this.updateDate=updateDate;
    }

}