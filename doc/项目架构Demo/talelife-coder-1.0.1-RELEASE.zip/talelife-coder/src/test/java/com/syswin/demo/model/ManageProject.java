package com.syswin.demo.model;
import java.util.Date;
/**
 * 管理项目实体类
 * date: 2017-01-20 16:14:49
 * 
 * @author Liuweiyao
 * @version 1.0
 */
public class ManageProject{
	//管理项目id
	private Long manageProjectId;
	
	//管理项目名称
	private String manageProjectName;
	
	//备注
	private String remark;
	
	//创建者id
	private Long createby;
	
	//创建者名称
	private String createbyName;
	
	//创建时间
	private Date createDate;
	
	//修改者id
	private Long updateby;
	
	//修改者名称
	private String updatebyName;
	
	//修改时间
	private Date updateDate;
	

	public Long getManageProjectId(){
		return manageProjectId;
	}
	
	public Long setManageProjectId(Long manageProjectId){
 	    return this.manageProjectId=manageProjectId;
    }
	public String getManageProjectName(){
		return manageProjectName;
	}
	
	public String setManageProjectName(String manageProjectName){
 	    return this.manageProjectName=manageProjectName;
    }
	public String getRemark(){
		return remark;
	}
	
	public String setRemark(String remark){
 	    return this.remark=remark;
    }
	public Long getCreateby(){
		return createby;
	}
	
	public Long setCreateby(Long createby){
 	    return this.createby=createby;
    }
	public String getCreatebyName(){
		return createbyName;
	}
	
	public String setCreatebyName(String createbyName){
 	    return this.createbyName=createbyName;
    }
	public Date getCreateDate(){
		return createDate;
	}
	
	public Date setCreateDate(Date createDate){
 	    return this.createDate=createDate;
    }
	public Long getUpdateby(){
		return updateby;
	}
	
	public Long setUpdateby(Long updateby){
 	    return this.updateby=updateby;
    }
	public String getUpdatebyName(){
		return updatebyName;
	}
	
	public String setUpdatebyName(String updatebyName){
 	    return this.updatebyName=updatebyName;
    }
	public Date getUpdateDate(){
		return updateDate;
	}
	
	public Date setUpdateDate(Date updateDate){
 	    return this.updateDate=updateDate;
    }

}