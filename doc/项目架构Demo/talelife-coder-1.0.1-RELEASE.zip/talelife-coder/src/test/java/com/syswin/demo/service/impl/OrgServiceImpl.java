package com.syswin.demo.service.impl;
import org.springframework.stereotype.Service;
import com.syswin.demo.service.OrgService;
import com.syswin.demo.mapper.OrgMapper;
import com.syswin.demo.model.Org;
import javax.annotation.Resource;
import java.util.List;
/**
 * 组织单元业务实现类
 * date: 2017-01-20 16:14:49
 * 
 * @author Liuweiyao
 * @version 1.0
 */
@Service
public class OrgServiceImpl implements OrgService{
	
	@Resource
	private OrgMapper orgMapper;
	
	public List<Org> findAll(){
		return orgMapper.findAll();
	}
	
	public List<Org> findList(Org org){
		return orgMapper.findList(org);
	}
	
	public int add(Org org){
		return orgMapper.add(org);
	}
	
	public int delete(Long orgUnitId){
		return orgMapper.delete(orgUnitId);
	}
	
	public int update(Org org){
		return orgMapper.update(org);
	}
	
	public Org findByPK(Long orgUnitId){
		return orgMapper.findByPK(orgUnitId);
	}
	
	
	
	
	
}