var app = angular.module('webapp', ['ngRoute']);
app.config(function($routeProvider) {
    $routeProvider

        .when('/movie', {
            templateUrl : 'module/movie/movie.html',
            controller : 'movieController'
        });
});
