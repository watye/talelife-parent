app.controller('movieController', function ($scope,$http) {
	$scope.list = [{"name":"b1","price":1},{"name":"b2","price":2}];
    $http.get("/movie/getAll")
        .success(function (data) {
        	console.log(data)
        	$scope.list = data;
        });
})