var express = require('express');
var soap = require('soap');
var app = express();
var router = express.Router();
var http = require('http');

app.get('/movie', function(req, res) {

    http.get({
        host: '127.0.0.1',
        port: 8080,
        agent: false,
        path: '/demo/movies'
    }, function(res1) {
        console.log('STATUS: ' + res1.statusCode);
        console.log('HEADERS: ' + JSON.stringify(res1.headers));
        res1.setEncoding('utf8');
        res1.on('data', function (data) {
            console.log(data);
            res.json(JSON.parse(data));
        });
    }).on('error', function(err) {
        logger.error(err);
        res.send(404);
    }).end();
});
app.get('/mobile', function(req, res) {
    var url="http://www.webxml.com.cn/WebServices/MobileCodeWS.asmx?wsdl";
    var args = { mobileCode: '18823660299'};
    soap.createClient(url, function(err, client) {
        client.getMobileCodeInfo(args, function(err, result) {
            console.log(result);
            res.json(result);
        });
    });

});

module.exports = app;
