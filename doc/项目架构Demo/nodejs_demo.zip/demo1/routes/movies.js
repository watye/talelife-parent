var Movie = require('../models/movie');
var express = require('express');
var app = express();
var router = express.Router();

app.get('/getAll', function(req, res) {
    Movie.find(function (err, movies) {
        if (err) {
            return res.send(err);
        }
        res.json(movies);
    })
});
app.get('/add', function(req, res) {
    var m = new Movie({"title":"aaaaa"});
    m.save(function(err){
        if (err) {
            return res.send(err);
        }
        res.send({message: 'add a movie'});
    });

});

module.exports = app;
