var mongoose = require('mongoose');
var express = require('express');
var bodyParser = require('body-parser');
var app = express();
var http = require('http');
var path = require('path');

//连接数据库
var url = 'mongodb://localhost:27017/test';
var mongoOptions = {
    server: {
        socketOptions: {
            keepAlive: 1
        }
    }
};
mongoose.connect(url, mongoOptions);
mongoose.connection.on('error', function (err) {
    console.log('Mongo Error:' + err);
}).on('open', function () {
    console.log('Connection opened');
});

//设置静态资源
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));
app.use(function(err, req, res, next) {//处理异常
    if(!err) return next();
    console.log(err.stack);
    res.json({error: true});
});
//设置路由
app.use('/movie', require('./routes/movies'));
app.use('/api', require('./routes/api'));
module.exports = app;
http.createServer(app);